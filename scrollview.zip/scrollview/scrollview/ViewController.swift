//
//  ViewController.swift
//  scrollview
//
//  Created by MAC on 15/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scrollVIEW: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    let screenwidth = UIScreen.main.bounds.size.width
    var count: Int = 0
    
    override func viewDidLoad() {
       super.viewDidLoad()
        
        scrollVIEW.delegate = self
        count = Int((scrollVIEW.frame.size.width)/screenwidth)
        pageControl.numberOfPages = count
        
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
            // let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
            let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
            pageControl.currentPage = Int(pageNumber)
        }
}


//    var colors:[UIColor] = [UIColor.red, UIColor.blue, UIColor.green, UIColor.yellow]
////var colors = ["aa","bb","cc","dd"]
//
//    @IBOutlet weak var pageCONTROL: UIPageControl!
//    @IBOutlet weak var scrollVIEW: UIScrollView!
//    @IBOutlet weak var contentVIEW: UIView!
//  //  @IBOutlet weak var imgVIEW: UIImageView!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        scrollVIEW.delegate = self
//        pageCONTROL.numberOfPages = colors.count
//        pageCONTROL.currentPage = 0
//
//        for index in 0..<4 {
//
//            contentVIEW.backgroundColor = colors[index]
//
//        }
//        pageCONTROL.addTarget(self, action: #selector(self.changePage(sender:)), for: UIControl.Event.valueChanged)
//        // Do any additional setup after loading the view.
//    }
//
//    @objc func changePage(sender: UIPageControl) -> () {
//            let x = CGFloat(pageCONTROL.currentPage) * scrollVIEW.frame.size.width
//            scrollVIEW.setContentOffset(CGPoint(x:x, y:0), animated: true)
//    }
//
//    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
//            let x = scrollView.contentOffset.x
//            let w = scrollView.bounds.size.width
//            pageCONTROL.currentPage = Int(x/w)
//    }
//}

//let scrollView = UIScrollView(frame: CGRect(x:0, y:0, width:375,height: 600))
//    var colors:[UIColor] = [UIColor.red, UIColor.blue, UIColor.green, UIColor.yellow]
//    var frame: CGRect = CGRect(x:0, y:0, width:0, height:0)
//    var pageControl : UIPageControl = UIPageControl(frame: CGRect(x:100,y: 610, width:200, height:50))
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        configurePageControl()
//
//        scrollView.delegate = self
//        scrollView.isPagingEnabled = true
//
//        self.view.addSubview(scrollView)
//        for index in 0..<4 {
//
//            frame.origin.x = self.scrollView.frame.size.width * CGFloat(index)
//            frame.size = self.scrollView.frame.size
//
//            let subView = UIView(frame: frame)
//            subView.backgroundColor = colors[index]
//            self.scrollView .addSubview(subView)
//        }
//
//        self.scrollView.contentSize = CGSize(width:self.scrollView.frame.size.width * 4,height: self.scrollView.frame.size.height)
//        pageControl.addTarget(self, action: #selector(self.changePage(sender:)), for: UIControl.Event.valueChanged)
//
//    }
//
//    func configurePageControl() {
//        self.pageControl.numberOfPages = colors.count
//        self.pageControl.currentPage = 0
//        self.pageControl.tintColor = UIColor.red
//        self.pageControl.pageIndicatorTintColor = UIColor.black
//        self.pageControl.currentPageIndicatorTintColor = UIColor.green
//        self.view.addSubview(pageControl)
//
//    }

//    @objc func changePage(sender: AnyObject) -> () {
//        let x = CGFloat(pageControl.currentPage) * scrollView.frame.size.width
//        scrollView.setContentOffset(CGPoint(x:x, y:0), animated: true)
//    }
//
//    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
//
//        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
//        pageControl.currentPage = Int(pageNumber)
//    }
//
//}
