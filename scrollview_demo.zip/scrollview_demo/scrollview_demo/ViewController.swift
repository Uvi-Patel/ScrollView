//
//  ViewController.swift
//  scrollview_demo
//
//  Created by MAC on 15/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var imgVIEW: UIImageView!
    @IBOutlet weak var scrollVIEW: UIScrollView!
    // @IBOutlet weak var scrollVIEW: UIScrollView!
    override func viewDidLoad() {
            super.viewDidLoad()
            
            scrollVIEW.delegate = self
            scrollVIEW.isScrollEnabled = true
            scrollVIEW.showsVerticalScrollIndicator = true
            scrollVIEW.maximumZoomScale = 3.0
            scrollVIEW.minimumZoomScale = 10
            
            }
        func viewForZooming(in scrollView: UIScrollView) -> UIView? {
            return imgVIEW
        }
        
        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            print("scrollViewDidScroll...")
           
        }

        func scrollViewDidZoom(_ scrollView: UIScrollView) {
            print("scrollViewDidZoom.....")
        }
        
        func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
            print("scrollViewWillBeginDragging...")
        }
        func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
            print("scrollViewWillEndDragging....")
        }
        
        func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
            print("scrollViewDidEndDragging....")
        }
        
        func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
            print("scrollViewWillBeginDecelerating...")
        }
        
        func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
            print("scrollViewDidEndDecelerating....")
        }
        
        func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
            print("scrollViewDidEndScrollingAnimation")
        }
        
        func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
            print("scrollViewWillBeginZooming....")
        }
        
        func scrollViewDidEndZooming(_ scrollView: UIScrollView, with view: UIView?, atScale scale: CGFloat) {
            print("scrollViewDidEndZooming")
        }
        
        func scrollViewDidScrollToTop(_ scrollView: UIScrollView) {
            print("scrollViewDidScrollToTop")
        }
        
        func scrollViewShouldScrollToTop(_ scrollView: UIScrollView) -> Bool {
            print("scrollViewShouldScrollToTop")
            return true
        }
        
        func scrollViewDidChangeAdjustedContentInset(_ scrollView: UIScrollView) {
            print("scrollViewDidChangeAdjustedContentInset")
        }
    }
